import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:whatsapp_love_sticker/modals/InstallStickersModal.dart';
import 'package:whatsapp_love_sticker/modals/StickerListModal.dart';
import 'package:whatsapp_love_sticker/screens/SplashScreen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => StickerListModel()),
        ChangeNotifierProvider(create: (_) => InstallStickersModal()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Romantic Stickers - Whatsapp Stickers',
        theme: ThemeData(
          primaryColor: Colors.blueAccent,
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        home: SplashScreen(),
      ),
    );
  }
}