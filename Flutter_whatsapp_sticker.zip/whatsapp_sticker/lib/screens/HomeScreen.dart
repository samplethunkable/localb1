import 'package:esys_flutter_share/esys_flutter_share.dart';
import 'package:flutter/material.dart';
import 'package:whatsapp_love_sticker/screens/StickerList.dart';
import 'package:url_launcher/url_launcher.dart';


class HomeScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Romantic Stickers',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold,fontFamily: "JosefinSans",),
        ),
        backgroundColor: Colors.amber[200],
        elevation: 0.0,
        automaticallyImplyLeading: false,
        actions: [
          Center(
            child: Text(
              'MR ❤️         ',
              style: TextStyle(
                fontSize: 18,
                color: Colors.blueAccent,
                fontFamily: "JosefinSans",
                fontWeight: FontWeight.bold,
                ),
                ),
                ),
        ],
      ),
      body: StickerList(),
    );
  }

}