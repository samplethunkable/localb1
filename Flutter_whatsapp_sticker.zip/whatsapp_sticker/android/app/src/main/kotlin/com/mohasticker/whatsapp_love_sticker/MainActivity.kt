package com.mohasticker.whatsapp_love_sticker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
