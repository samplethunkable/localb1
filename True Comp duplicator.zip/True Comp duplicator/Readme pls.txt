-----------------------------https://gxfreee.com

True Comp Duplicator v3.11

its very usefull plugins for adobe after effect

how to install:

	1.True Comp Duplicator
	2.copy "True Comp Duplicator.jsx"file
	3.paste (C:\Program Files\Adobe\Adobe After effict cc 2017 (or)\Scripts\ScriptUI Panels) paste this path
	4.and open your Adobe After effict
	5.enjoy True Comp Duplicator

any doubt pls comment my website


-----------------------------------------------------